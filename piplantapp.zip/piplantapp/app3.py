from flask import Flask, render_template
import threading
import paho.mqtt.client as mqtt
import os
from sense_hat import SenseHat
import requests

import time
import json
import queue

app = Flask(__name__)
sense = SenseHat()
mqtt_data_queue = queue.Queue()


# Weather API Configuration
API_KEY = "e4b29104f86ccc4035dc6810a5ac80fa"  # Get your free API key from OpenWeatherMap
CITY = "Carlow,IE"
API_URL = f"http://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"

broker = "192.168.0.32"  # Replace with your Mosquitto broker's IP address
topic2 = "sensor/LightResistor"


def get_real_weather():
    """Fetch real-time temperature and humidity from OpenWeatherMap."""
    try:
        response = requests.get(API_URL)
        response.raise_for_status()  # Raise an exception for HTTP errors
        data = response.json()
        return {
            "temperature": data['main']['temp'],  # Current temperature in Celsius
            "humidity": data['main']['humidity']  # Current humidity in percentage
        }
    except Exception as e:
        print(f"Error fetching weather data: {e}")
        return None

def calibrate_readings():
    """Calibrate Sense HAT readings using real temperature and humidity."""
    # Read Sense HAT temperature and humidity
    sense_temperature = sense.get_temperature()
    sense_humidity = sense.get_humidity()

    # Fetch real weather data from the API
    real_weather = get_real_weather()
    if real_weather is None:
        print("Unable to fetch real weather data. Using raw Sense HAT readings.")
        return sense_temperature, sense_humidity

    # Calculate temperature offset and corrected value
    temperature_offset = sense_temperature - real_weather["temperature"]
    corrected_temperature = sense_temperature - temperature_offset

    # Calculate humidity offset and corrected value
    humidity_offset = sense_humidity - real_weather["humidity"]
    corrected_humidity = sense_humidity - humidity_offset

    return corrected_temperature, corrected_humidity

# Fetch and display corrected readings
corrected_temperature, corrected_humidity = calibrate_readings()


# Flask route for the web server
@app.route('/')
def index():
    try:
        #mqtt_data = mqtt_data_queue.get_nowait()
        #return f"Latest Temperature: {mqtt_data}"
    
        # Gather data from Sense HAT
        temperature = corrected_temperature
        humidity = corrected_humidity
        far_temperature = sense.get_temperature()
        far_humidity = sense.get_humidity()
        photoResistor=0
	# Pass the data to the HTML template
        sense.show_message(f"{temperature:.1f}C", scroll_speed=0.05) # sense temperature
        sense.show_message(f"{humidity: .2f}%")
        sense.show_message(f"{photoResistor: .2f} %")
        time.sleep(3)
        return render_template('index.html',
                                 temperature=round(temperature, 2),
                                 humidity=round(humidity, 2),
                                 ftemperature=round(far_temperature, 2),
                                 fphotoResistor=round(photoResistor,2),
                                 fhumidity=round(far_humidity, 2)  )
    except queue.Empty:
        # Gather data from Sense HAT
        temperature = corrected_temperature
        humidity = corrected_humidity
        far_temperature = sense.get_temperature()
        far_humidity = sense.get_humidity()
        photoResistor=0
 
       # Pass the data to the HTML template
        sense.show_message(f"{temperature:.1f}C", scroll_speed=0.05) # sense temperature
        sense.show_message(f"{humidity: .2f}%")
        sense.show_message(f"{photoResistor: .2f} %")
        time.sleep(3)
        return render_template('index.html',
                                 temperature=round(temperature, 2),
                                 humidity=round(humidity, 2),
                                 ftemperature=round(far_temperature, 2),
                	         fphotoResistor=round(photoResistor,2),

                                 fhumidity=round(far_humidity, 2)  )

        
def on_message(client, userdata, message):
    mqtt_data = message.payload.decode()  # Decode byte data to string
    print(f"Received message: {mqtt_data} on topic {message.topic}")
    mqtt_data_queue.put(mqtt_data)  # Put the received message into the queue

    
# MQTT Subscriber function
def mqtt_subscriber():
    client = mqtt.Client()
    client.on_message = on_message  # Set the callback function

    # Connect to the broker
    client.connect(broker, 1883, 60)

    # Subscribe to the topic
    client.subscribe(topic)

    # Start the loop to process incoming messages
    client.loop_forever()

def mqtt_subscriber():
    client = mqtt.Client()
    client.on_message = on_message  # Set the callback function

    # Connect to the broker
    client.connect(broker, 1883, 60)

    # Subscribe to the topic
    client.subscribe(topic)

    # Start the loop to process incoming messages
    client.loop_forever()

# Function to start Flask server
def start_flask():
    app.run(debug=True, use_reloader=False, port=5001)
  # Set `use_reloader=False` to avoid conflicts with threading

if __name__ == "__main__":
    # Start Flask server in a separate thread
    flask_thread = threading.Thread(target=start_flask)
    flask_thread.start()

    # Start MQTT publisher in another thread
    mqtt_thread = threading.Thread(target=mqtt_publisher)
    mqtt_thread.start()
# Create MQTT client
#client = mqtt.Client()

# Assign callback
#client.on_message = on_message

# Connect to the broker
#client.connect(broker, 1883, 60)

# Subscribe to the topic
#client.subscribe(topic2)

# Start the MQTT loop
#print(f"Subscribed to topic {topic2}")
#client.loop_forever()
